// ═══════════════════════════════════════════════════════════════
//  JAYNES MAX TV — src/index.js
//  Express server — entry point
// ═══════════════════════════════════════════════════════════════

require('dotenv').config();
const express   = require('express');
const cors      = require('cors');
const rateLimit = require('express-rate-limit');
const { startKeepAlive } = require('./utils/keepAlive');

const authRoutes          = require('./routes/auth');
const channelsRoutes      = require('./routes/channels');
const azamRoutes          = require('./routes/azam');
const nbcRoutes           = require('./routes/nbc');
const keyRoutes           = require('./routes/key');
const epgRoutes           = require('./routes/epg');
const subscriptionRoutes  = require('./routes/subscription');
const favoritesRoutes     = require('./routes/favorites');
const searchRoutes        = require('./routes/search');
const updateRoutes        = require('./routes/update');
const notificationsRoutes = require('./routes/notifications');
const profileRoutes       = require('./routes/profile');
const { router: streamRoutes } = require('./routes/stream');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors({ origin: '*' }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const limiter = rateLimit({
  windowMs : 60 * 1000,
  max      : 100,
  message  : { success: false, error: 'Ombi nyingi sana. Jaribu tena baadaye.' },
});
app.use('/api/', limiter);

app.use('/api/auth',          authRoutes);
app.use('/api/channels',      channelsRoutes);
app.use('/api/azam',          azamRoutes);
app.use('/api/nbc',           nbcRoutes);
app.use('/api/key',           keyRoutes);
app.use('/api/epg',           epgRoutes);
app.use('/api/sub',           subscriptionRoutes);
app.use('/api/plans',         subscriptionRoutes);
app.use('/api/favorites',     favoritesRoutes);
app.use('/api/search',        searchRoutes);
app.use('/api/update',        updateRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/profile',       profileRoutes);
app.use('/stream',            streamRoutes);

app.get('/api/health', (_req, res) => {
  res.json({
    success  : true,
    service  : 'JAYNES MAX TV API',
    version  : '1.0.0',
    time     : new Date().toISOString(),
    uptime_s : Math.floor(process.uptime()),
  });
});

app.use((_req, res) => {
  res.status(404).json({ success: false, error: 'Endpoint haipatikani.' });
});

app.use((err, _req, res, _next) => {
  console.error('[ERROR]', err.message);
  res.status(500).json({ success: false, error: 'Hitilafu ya seva. Jaribu tena.' });
});

app.listen(PORT, () => {
  console.log(`✅ JAYNES MAX TV API — port ${PORT}`);
  // Anza keep-alive baada ya server kuwa tayari
  startKeepAlive();
});
