// ═══════════════════════════════════════════════════════════════
//  JAYNES MAX TV — src/routes/channels.js
//  Channels: orodha, categories, stream URL
//
//  GET  /api/channels/list         — channels zote (filter kwa plan)
//  GET  /api/channels/categories   — makundi ya channels
//  GET  /api/channels/:id          — channel moja kwa maelezo yake yote
//  GET  /api/channels/stream/:id   — stream URL (protected)
//  POST /api/channels/admin        — (admin) ongeza channel
//  PATCH /api/channels/admin/:id   — (admin) hariri channel
//  DELETE /api/channels/admin/:id  — (admin) futa channel
// ═══════════════════════════════════════════════════════════════

const express        = require('express');
const NodeCache      = require('node-cache');
const { supabaseRequest } = require('../utils/supabase');
const authMiddleware      = require('../middleware/auth');

const router = express.Router();
const cache  = new NodeCache({ stdTTL: parseInt(process.env.CACHE_TTL_CHANNELS) || 300 });

// ── Plan hierarchy ───────────────────────────────────────────
const PLAN_LEVEL = { trial: 0, free: 0, basic: 1, standard: 2, premium: 3 };

function planAllowed(userPlan, requiredPlan) {
  return (PLAN_LEVEL[userPlan] ?? 0) >= (PLAN_LEVEL[requiredPlan ?? 'basic'] ?? 1);
}

// ── Helper: angalia admin ─────────────────────────────────────
function isAdmin(req) {
  const adminEmails = (process.env.ADMIN_EMAILS || '').split(',').map(e => e.trim());
  return adminEmails.includes(req.user?.email);
}

// ════════════════════════════════════════════════════════════════
//  GET /api/channels/list
//  Query: ?category=SPORTS&limit=50&plan=standard&refresh=1
// ════════════════════════════════════════════════════════════════
router.get('/list', async (req, res) => {
  const category = (req.query.category || '').toUpperCase();
  const limit    = Math.min(parseInt(req.query.limit) || 100, 200);
  const cacheKey = `channels_${category}_${limit}`;

  // Pata plan ya mtumiaji kama ameingia
  let userPlan = 'free';
  const authHeader = req.headers['authorization'] || '';
  if (authHeader.startsWith('Bearer ')) {
    try {
      const jwt     = require('jsonwebtoken');
      const decoded = jwt.verify(authHeader.slice(7), process.env.JWT_SECRET);
      userPlan = decoded.plan || 'free';
    } catch { /* haujaingia — free */ }
  }

  const cached = cache.get(cacheKey);
  if (cached && !req.query.refresh) {
    // Weka locked flag kulingana na plan ya mtumiaji
    const withLocked = cached.channels.map(ch => ({
      ...ch,
      locked: !planAllowed(userPlan, ch.required_plan),
      stream_url: planAllowed(userPlan, ch.required_plan) ? ch.stream_url : null,
    }));
    return res.json({ ...cached, channels: withLocked, user_plan: userPlan });
  }

  let path = '/channels?is_active=eq.true&select=id,name,logo_url,category,language,country,description,is_premium,required_plan,sort_order,tags,backup_url,stream_url&order=sort_order.asc,name.asc';

  if (category) {
    path += `&category=eq.${encodeURIComponent(category)}`;
  }
  path += `&limit=${limit}`;

  const result = await supabaseRequest(path, 'GET', null, true);

  if (!result.success) {
    return res.status(502).json({ success: false, error: 'Imeshindwa kupata channels.' });
  }

  const channels = (result.data || []).map(ch => ({
    ...ch,
    locked    : !planAllowed(userPlan, ch.required_plan),
    stream_url: planAllowed(userPlan, ch.required_plan) ? ch.stream_url : null,
  }));

  const payload = {
    success    : true,
    count      : channels.length,
    fetched_at : new Date().toISOString(),
    channels,
    user_plan  : userPlan,
  };

  // Cache bila locked flag — inahusiana na mtumiaji mmoja mmoja
  cache.set(cacheKey, {
    ...payload,
    channels: result.data || [],
  });

  return res.json(payload);
});

// ════════════════════════════════════════════════════════════════
//  GET /api/channels/categories
// ════════════════════════════════════════════════════════════════
router.get('/categories', async (_req, res) => {
  const cacheKey = 'channel_categories';
  const cached   = cache.get(cacheKey);
  if (cached) return res.json(cached);

  const result = await supabaseRequest(
    '/channels?is_active=eq.true&select=category&order=category.asc',
    'GET', null, true
  );

  if (!result.success) {
    return res.status(502).json({ success: false, error: 'Imeshindwa kupata categories.' });
  }

  // Hesabu channels kwa kila category
  const countMap = {};
  for (const ch of (result.data || [])) {
    countMap[ch.category] = (countMap[ch.category] || 0) + 1;
  }

  const categories = Object.entries(countMap)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => a.name.localeCompare(b.name));

  const payload = { success: true, count: categories.length, categories };
  cache.set(cacheKey, payload);
  return res.json(payload);
});

// ════════════════════════════════════════════════════════════════
//  GET /api/channels/:id — channel moja (maelezo kamili)
// ════════════════════════════════════════════════════════════════
router.get('/:id', async (req, res) => {
  const { id } = req.params;

  const result = await supabaseRequest(
    `/channels?id=eq.${id}&is_active=eq.true&select=*`,
    'GET', null, true
  );

  if (!result.success || !result.data?.length) {
    return res.status(404).json({ success: false, error: 'Channel haipatikani.' });
  }

  const ch = result.data[0];

  // Angalia plan ya mtumiaji
  let userPlan = 'free';
  const authHeader = req.headers['authorization'] || '';
  if (authHeader.startsWith('Bearer ')) {
    try {
      const jwt     = require('jsonwebtoken');
      const decoded = jwt.verify(authHeader.slice(7), process.env.JWT_SECRET);
      userPlan = decoded.plan || 'free';
    } catch { /* */ }
  }

  return res.json({
    success  : true,
    channel  : {
      ...ch,
      locked    : !planAllowed(userPlan, ch.required_plan),
      stream_url: planAllowed(userPlan, ch.required_plan) ? ch.stream_url : null,
      drm_key   : planAllowed(userPlan, ch.required_plan) ? ch.drm_key   : null,
    },
  });
});

// ════════════════════════════════════════════════════════════════
//  GET /api/channels/stream/:id — stream URL (inahitaji login)
// ════════════════════════════════════════════════════════════════
router.get('/stream/:id', authMiddleware, async (req, res) => {
  const { id }     = req.params;
  const userPlan   = req.user.plan || 'free';

  // Angalia subscription imeisha
  const subEnd   = req.user.sub_end   || req.user.trial_end;
  const planName = req.user.plan;

  if (planName !== 'trial' && subEnd && new Date(subEnd) < new Date()) {
    return res.status(403).json({
      success : false,
      error   : 'Subscription yako imeisha. Lipia ili kuendelea.',
      code    : 'SUB_EXPIRED',
    });
  }

  const result = await supabaseRequest(
    `/channels?id=eq.${id}&is_active=eq.true&select=id,name,stream_url,backup_url,drm_type,drm_key,required_plan`,
    'GET', null, true
  );

  if (!result.success || !result.data?.length) {
    return res.status(404).json({ success: false, error: 'Channel haipatikani.' });
  }

  const ch = result.data[0];

  // Angalia kama plan inatosha
  if (!planAllowed(userPlan, ch.required_plan)) {
    return res.status(403).json({
      success       : false,
      error         : `Channel hii inahitaji plan ya '${ch.required_plan}'. Plan yako: '${userPlan}'.`,
      code          : 'PLAN_REQUIRED',
      required_plan : ch.required_plan,
    });
  }

  return res.json({
    success    : true,
    channel_id : id,
    stream_url : ch.stream_url,
    backup_url : ch.backup_url || null,
    drm_type   : ch.drm_type  || 'NONE',
    drm_key    : ch.drm_key   || null,
  });
});

// ════════════════════════════════════════════════════════════════
//  ADMIN ROUTES — zinahitaji login + admin email
// ════════════════════════════════════════════════════════════════

// ── POST /api/channels/admin — ongeza channel ────────────────
router.post('/admin', authMiddleware, async (req, res) => {
  if (!isAdmin(req)) {
    return res.status(403).json({ success: false, error: 'Ruhusa ya admin inahitajika.' });
  }

  const {
    name, logo_url, stream_url, backup_url,
    category, drm_type, drm_key, is_active,
    is_premium, required_plan, sort_order,
    language, country, description, tags,
  } = req.body;

  if (!name || !stream_url || !category) {
    return res.status(400).json({ success: false, error: 'name, stream_url, na category zinahitajika.' });
  }

  const result = await supabaseRequest('/channels', 'POST', {
    name,
    logo_url     : logo_url     || null,
    stream_url,
    backup_url   : backup_url   || null,
    category     : category.toUpperCase(),
    drm_type     : drm_type     || 'NONE',
    drm_key      : drm_key      || null,
    is_active    : is_active    !== false,
    is_premium   : is_premium   || false,
    required_plan: required_plan || 'basic',
    sort_order   : sort_order   || 999,
    language     : language     || 'sw',
    country      : country      || 'TZ',
    description  : description  || '',
    tags         : tags         || [],
    created_at   : new Date().toISOString(),
  }, true);

  if (!result.success) {
    return res.status(500).json({ success: false, error: 'Imeshindwa kuongeza channel.' });
  }

  cache.flushAll(); // Futa cache yote baada ya mabadiliko
  return res.status(201).json({ success: true, channel: result.data?.[0] || null });
});

// ── PATCH /api/channels/admin/:id — hariri channel ───────────
router.patch('/admin/:id', authMiddleware, async (req, res) => {
  if (!isAdmin(req)) {
    return res.status(403).json({ success: false, error: 'Ruhusa ya admin inahitajika.' });
  }

  const { id } = req.params;
  const allowed = [
    'name', 'logo_url', 'stream_url', 'backup_url',
    'category', 'drm_type', 'drm_key', 'is_active',
    'is_premium', 'required_plan', 'sort_order',
    'language', 'country', 'description', 'tags',
  ];

  const updates = {};
  for (const key of allowed) {
    if (req.body[key] !== undefined) updates[key] = req.body[key];
  }

  if (!Object.keys(updates).length) {
    return res.status(400).json({ success: false, error: 'Hakuna mabadiliko yaliyotolewa.' });
  }

  updates.updated_at = new Date().toISOString();

  const result = await supabaseRequest(`/channels?id=eq.${id}`, 'PATCH', updates, true);

  if (!result.success) {
    return res.status(500).json({ success: false, error: 'Imeshindwa kusasisha channel.' });
  }

  cache.flushAll();
  return res.json({ success: true, message: 'Channel imesasishwa.' });
});

// ── DELETE /api/channels/admin/:id — futa channel ────────────
router.delete('/admin/:id', authMiddleware, async (req, res) => {
  if (!isAdmin(req)) {
    return res.status(403).json({ success: false, error: 'Ruhusa ya admin inahitajika.' });
  }

  const { id } = req.params;

  // Badala ya kufuta — zima tu (soft delete)
  const result = await supabaseRequest(
    `/channels?id=eq.${id}`,
    'PATCH',
    { is_active: false, updated_at: new Date().toISOString() },
    true
  );

  if (!result.success) {
    return res.status(500).json({ success: false, error: 'Imeshindwa kufuta channel.' });
  }

  cache.flushAll();
  return res.json({ success: true, message: 'Channel imezimwa.' });
});

module.exports = router;
