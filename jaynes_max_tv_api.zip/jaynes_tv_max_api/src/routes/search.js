// ═══════════════════════════════════════════════════════════════
//  JAYNES MAX TV — src/routes/search.js
//  Tafuta channels kwa jina, category, tags
//
//  GET /api/search?q=azam&filter=SPORTS
// ═══════════════════════════════════════════════════════════════

const express        = require('express');
const { supabaseRequest } = require('../utils/supabase');

const router = express.Router();

// ── GET /api/search ───────────────────────────────────────────
router.get('/', async (req, res) => {
  const q      = (req.query.q      || '').trim();
  const filter = (req.query.filter || '').trim().toUpperCase();
  const limit  = Math.min(parseInt(req.query.limit) || 20, 50);

  if (!q && !filter) {
    return res.status(400).json({ success: false, error: 'Weka neno la kutafuta (q) au filter ya category.' });
  }

  // Jenga query ya Supabase
  let path = '/channels?is_active=eq.true&select=id,name,logo_url,category,language,is_premium,sort_order';

  if (q) {
    // Supabase ilike search (case-insensitive)
    path += `&name=ilike.*${encodeURIComponent(q)}*`;
  }

  if (filter) {
    path += `&category=eq.${encodeURIComponent(filter)}`;
  }

  path += `&order=sort_order.asc,name.asc&limit=${limit}`;

  const result = await supabaseRequest(path, 'GET', null, true);

  if (!result.success) {
    return res.status(502).json({ success: false, error: 'Utafutaji umeshindwa. Jaribu tena.' });
  }

  return res.json({
    success  : true,
    query    : q,
    filter,
    count    : (result.data || []).length,
    channels : result.data || [],
  });
});

// ── GET /api/search/trending ──────────────────────────────────
// Channels zinazofuatwa zaidi (kutoka watch_history)
router.get('/trending', async (_req, res) => {
  // Kwa sasa — rejesha channels zote zilizopangwa kwa sort_order
  // (Baadaye: aggregate kutoka watch_history)
  const result = await supabaseRequest(
    '/channels?is_active=eq.true&select=id,name,logo_url,category,is_premium&order=sort_order.asc&limit=10',
    'GET', null, true
  );

  return res.json({
    success  : true,
    trending : result.data || [],
  });
});

module.exports = router;
