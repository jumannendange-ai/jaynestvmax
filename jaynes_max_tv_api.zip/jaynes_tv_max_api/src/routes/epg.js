// ═══════════════════════════════════════════════════════════════
//  JAYNES MAX TV — src/routes/epg.js
//  Electronic Programme Guide (TV Guide)
//
//  GET /api/epg/:channel_id        — schedule ya channel moja
//  GET /api/epg/now-next           — inaonyesha nini sasa katika channels zote
//  POST /api/epg/admin             — (admin) ongeza programme [service key]
// ═══════════════════════════════════════════════════════════════

const express   = require('express');
const NodeCache = require('node-cache');
const { supabaseRequest } = require('../utils/supabase');
const authMiddleware = require('../middleware/auth');

const router = express.Router();
const cache  = new NodeCache({ stdTTL: parseInt(process.env.CACHE_TTL_EPG) || 3600 });

// ── GET /api/epg/now-next ─────────────────────────────────────
// Inapaswa kuwa kabla ya /:channel_id ili isishindwe na route hiyo
router.get('/now-next', async (req, res) => {
  const cacheKey = 'epg_now_next';
  const cached = cache.get(cacheKey);
  if (cached && !req.query.refresh) return res.json(cached);

  const now = new Date().toISOString();

  const result = await supabaseRequest(
    `/epg_programmes?start_time=lte.${now}&end_time=gte.${now}&select=id,channel_id,title,description,start_time,end_time,category,poster_url,is_live&order=channel_id.asc`,
    'GET', null, false
  );

  if (!result.success) {
    return res.status(502).json({ success: false, error: 'Imeshindwa kupata EPG data.' });
  }

  // Gawanya kwa channel_id — kila channel ina "now" na "next"
  const programmes = result.data || [];
  const byChannel  = {};

  for (const prog of programmes) {
    const cid = prog.channel_id;
    if (!byChannel[cid]) byChannel[cid] = { now: null, next: null };

    const start = new Date(prog.start_time);
    const end   = new Date(prog.end_time);
    const nowTs = Date.now();

    if (start <= nowTs && end >= nowTs) {
      byChannel[cid].now = prog;
    }
  }

  // Pata "next" kwa kila channel
  const nextResult = await supabaseRequest(
    `/epg_programmes?start_time=gt.${now}&select=id,channel_id,title,start_time,end_time,category&order=channel_id.asc,start_time.asc`,
    'GET', null, false
  );

  const nextSeen = new Set();
  for (const prog of (nextResult.data || [])) {
    const cid = prog.channel_id;
    if (!byChannel[cid]) byChannel[cid] = { now: null, next: null };
    if (!nextSeen.has(cid)) {
      byChannel[cid].next = prog;
      nextSeen.add(cid);
    }
  }

  const payload = {
    success    : true,
    fetched_at : new Date().toISOString(),
    channels   : byChannel,
  };

  cache.set(cacheKey, payload);
  return res.json(payload);
});

// ── GET /api/epg/:channel_id ──────────────────────────────────
router.get('/:channel_id', async (req, res) => {
  const { channel_id } = req.params;
  const days  = Math.min(parseInt(req.query.days) || 1, 7); // max siku 7
  const cacheKey = `epg_${channel_id}_${days}`;

  const cached = cache.get(cacheKey);
  if (cached && !req.query.refresh) return res.json(cached);

  const from = new Date();
  from.setHours(0, 0, 0, 0);
  const to = new Date(from);
  to.setDate(to.getDate() + days);

  const result = await supabaseRequest(
    `/epg_programmes?channel_id=eq.${channel_id}&start_time=gte.${from.toISOString()}&start_time=lt.${to.toISOString()}&select=*&order=start_time.asc`,
    'GET', null, false
  );

  if (!result.success) {
    return res.status(502).json({ success: false, error: 'Imeshindwa kupata EPG ya channel hii.' });
  }

  const payload = {
    success    : true,
    channel_id,
    days,
    count      : (result.data || []).length,
    programmes : result.data || [],
  };

  cache.set(cacheKey, payload);
  return res.json(payload);
});

// ── POST /api/epg/admin — ongeza/hariri programme (admin tu) ─
router.post('/admin', authMiddleware, async (req, res) => {
  // Hii route itatumika na Admin Panel tu — JWT ya admin inahitajika
  const { channel_id, title, description, start_time, end_time, category, poster_url } = req.body;

  if (!channel_id || !title || !start_time || !end_time) {
    return res.status(400).json({ success: false, error: 'channel_id, title, start_time, end_time zinahitajika.' });
  }

  const result = await supabaseRequest('/epg_programmes', 'POST', {
    channel_id, title, description: description || '',
    start_time, end_time,
    category   : category   || 'OTHER',
    poster_url : poster_url || null,
    is_live    : false,
    is_repeat  : false,
  }, true);

  if (!result.success) {
    return res.status(500).json({ success: false, error: 'Imeshindwa kuongeza programme.' });
  }

  // Futa cache ya channel hiyo
  cache.del(`epg_${channel_id}_1`);
  cache.del('epg_now_next');

  return res.status(201).json({ success: true, programme: result.data?.[0] || null });
});

module.exports = router;
