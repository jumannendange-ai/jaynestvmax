// ═══════════════════════════════════════════════════════════════
//  JAYNES MAX TV — src/routes/notifications.js
//  Push notifications via OneSignal + in-app notification log
//
//  GET  /api/notifications         — orodha ya notifications za mtumiaji
//  POST /api/notifications/send    — (admin) tuma push notification
//  PATCH /api/notifications/:id/read — weka notification kama imesomwa
// ═══════════════════════════════════════════════════════════════

const express   = require('express');
const axios     = require('axios');
const { supabaseRequest } = require('../utils/supabase');
const authMiddleware      = require('../middleware/auth');

const router = express.Router();

const ONESIGNAL_API  = 'https://api.onesignal.com/notifications';
const ONESIGNAL_APP  = process.env.ONESIGNAL_APP_ID;
const ONESIGNAL_KEY  = process.env.ONESIGNAL_REST_KEY;

// ── Segments za OneSignal ─────────────────────────────────────
const SEGMENTS = {
  all       : 'All',
  premium   : 'premium_users',
  standard  : 'standard_users',
  trial     : 'trial_users',
  expired   : 'expired_users',
};

// ── GET /api/notifications ─────────────────────────────────────
router.get('/', authMiddleware, async (req, res) => {
  const uid   = req.user.user_id;
  const limit = Math.min(parseInt(req.query.limit) || 20, 50);

  const result = await supabaseRequest(
    `/notifications_log?user_id=eq.${uid}&select=*&order=created_at.desc&limit=${limit}`,
    'GET', null, true
  );

  if (!result.success) {
    return res.status(502).json({ success: false, error: 'Imeshindwa kupata notifications.' });
  }

  const notifications = result.data || [];
  const unread        = notifications.filter(n => !n.read_at).length;

  return res.json({ success: true, unread, count: notifications.length, notifications });
});

// ── PATCH /api/notifications/:id/read ─────────────────────────
router.patch('/:id/read', authMiddleware, async (req, res) => {
  const uid = req.user.user_id;
  const { id } = req.params;

  await supabaseRequest(
    `/notifications_log?id=eq.${id}&user_id=eq.${uid}`,
    'PATCH',
    { read_at: new Date().toISOString() },
    true
  );

  return res.json({ success: true });
});

// ── POST /api/notifications/send — admin tu ──────────────────
router.post('/send', authMiddleware, async (req, res) => {
  const adminEmails = (process.env.ADMIN_EMAILS || '').split(',').map(e => e.trim());
  if (!adminEmails.includes(req.user.email)) {
    return res.status(403).json({ success: false, error: 'Ruhusa ya admin inahitajika.' });
  }

  const {
    title,
    body,
    segment = 'all',   // all | premium | standard | trial | expired
    type    = 'general', // match_alert | sub_expiry | new_channel | update | breaking_news | general
    user_id = null,    // kama ni notification kwa mtu mmoja tu
    data    = {},
  } = req.body;

  if (!title || !body) {
    return res.status(400).json({ success: false, error: 'title na body zinahitajika.' });
  }

  // ── Tuma kwa OneSignal ────────────────────────────────────
  let oneSignalResult = null;

  if (ONESIGNAL_APP && ONESIGNAL_KEY) {
    const payload = {
      app_id            : ONESIGNAL_APP,
      headings          : { en: title, sw: title },
      contents          : { en: body,  sw: body },
      data              : { type, ...data },
    };

    if (user_id) {
      // Tuma kwa mtumiaji mmoja kwa external_id
      payload.include_aliases       = { external_id: [user_id] };
      payload.target_channel        = 'push';
    } else {
      payload.included_segments = [SEGMENTS[segment] || SEGMENTS.all];
    }

    try {
      const osRes = await axios.post(ONESIGNAL_API, payload, {
        headers: {
          Authorization : `Key ${ONESIGNAL_KEY}`,
          'Content-Type': 'application/json',
        },
        timeout: 10000,
      });
      oneSignalResult = osRes.data;
    } catch (err) {
      console.error('[notify] OneSignal error:', err.message);
    }
  }

  // ── Hifadhi kwenye notifications_log (kwa mtumiaji mmoja) ─
  if (user_id) {
    await supabaseRequest('/notifications_log', 'POST', {
      user_id,
      title,
      body,
      type,
      read_at    : null,
      created_at : new Date().toISOString(),
    }, true);
  }

  return res.json({
    success      : true,
    message      : `Notification imetumwa${user_id ? ' kwa mtumiaji' : ` kwa segment '${segment}'`}.`,
    onesignal    : oneSignalResult,
    manual_mode  : !ONESIGNAL_APP,
  });
});

module.exports = router;
