// ═══════════════════════════════════════════════════════════════
//  JAYNES MAX TV — src/routes/update.js
//  App Update System
//
//  GET  /api/update/check          — angalia update ya app
//  GET  /api/update/latest         — toleo jipya zaidi (raw)
//  POST /api/update/admin          — (admin) ingiza toleo jipya
//  PATCH /api/update/admin/:id     — (admin) hariri toleo
// ═══════════════════════════════════════════════════════════════

const express   = require('express');
const NodeCache = require('node-cache');
const { supabaseRequest } = require('../utils/supabase');
const authMiddleware      = require('../middleware/auth');

const router = express.Router();
const cache  = new NodeCache({ stdTTL: 300 }); // cache dakika 5

// ── Helper: angalia admin ─────────────────────────────────────
function isAdmin(req) {
  const adminEmails = (process.env.ADMIN_EMAILS || '').split(',').map(e => e.trim());
  return adminEmails.includes(req.user?.email);
}

// ── Helper: linganisha version strings ───────────────────────
// Rejesha true kama versionB ni mpya kuliko versionA
function isNewer(versionA, versionB) {
  const parse = v => (v || '0.0.0').split('.').map(Number);
  const a = parse(versionA);
  const b = parse(versionB);

  for (let i = 0; i < 3; i++) {
    if ((b[i] || 0) > (a[i] || 0)) return true;
    if ((b[i] || 0) < (a[i] || 0)) return false;
  }
  return false;
}

// ════════════════════════════════════════════════════════════════
//  GET /api/update/check?version=1.0.0&version_code=1
//  Jibu: update ipo au hapana, force au optional, APK URL
// ════════════════════════════════════════════════════════════════
router.get('/check', async (req, res) => {
  const currentVersion     = req.query.version      || '0.0.0';
  const currentVersionCode = parseInt(req.query.version_code) || 0;

  // ── Pata toleo jipya zaidi kutoka DB ─────────────────────
  const cacheKey = 'latest_version';
  let latest     = cache.get(cacheKey);

  if (!latest || req.query.refresh) {
    const result = await supabaseRequest(
      '/app_versions?select=*&order=created_at.desc&limit=1',
      'GET', null, false
    );

    if (!result.success || !result.data?.length) {
      // Kama DB iko tupu — rejesha "hakuna update"
      return res.json({
        success      : true,
        update_available: false,
        current      : currentVersion,
        latest       : currentVersion,
        message      : 'App yako ni ya kisasa.',
      });
    }

    latest = result.data[0];
    cache.set(cacheKey, latest);
  }

  const updateAvailable = isNewer(currentVersion, latest.version_name) ||
                          (latest.version_code > currentVersionCode);

  if (!updateAvailable) {
    return res.json({
      success          : true,
      update_available : false,
      current          : currentVersion,
      latest           : latest.version_name,
      message          : 'App yako ni ya kisasa.',
    });
  }

  return res.json({
    success          : true,
    update_available : true,
    force            : latest.force_update || false,
    type             : latest.type         || 'minor',
    current          : currentVersion,
    latest           : latest.version_name,
    version_code     : latest.version_code,
    apk_url          : latest.apk_url,
    apk_sha256       : latest.apk_sha256   || null,
    size_mb          : latest.size_mb      || null,
    changelog        : latest.changelog    || [],
    message          : latest.force_update
      ? 'Toleo jipya muhimu lipo. Lazima upakue ili kuendelea.'
      : `Toleo jipya ${latest.version_name} lipo. Pakua sasa!`,
    released_at      : latest.created_at,
  });
});

// ════════════════════════════════════════════════════════════════
//  GET /api/update/latest — toleo jipya zaidi (raw JSON)
// ════════════════════════════════════════════════════════════════
router.get('/latest', async (_req, res) => {
  const result = await supabaseRequest(
    '/app_versions?select=*&order=created_at.desc&limit=1',
    'GET', null, false
  );

  if (!result.success || !result.data?.length) {
    return res.status(404).json({ success: false, error: 'Hakuna toleo lililohifadhiwa.' });
  }

  return res.json({ success: true, version: result.data[0] });
});

// ════════════════════════════════════════════════════════════════
//  GET /api/update/history — historia ya versions zote
// ════════════════════════════════════════════════════════════════
router.get('/history', async (_req, res) => {
  const result = await supabaseRequest(
    '/app_versions?select=version_name,version_code,type,force_update,changelog,created_at&order=created_at.desc&limit=20',
    'GET', null, false
  );

  return res.json({
    success  : true,
    count    : (result.data || []).length,
    versions : result.data || [],
  });
});

// ════════════════════════════════════════════════════════════════
//  POST /api/update/admin — (admin) ingiza toleo jipya
//  Body: { version_name, version_code, type, force_update, apk_url, apk_sha256, size_mb, changelog[] }
// ════════════════════════════════════════════════════════════════
router.post('/admin', authMiddleware, async (req, res) => {
  if (!isAdmin(req)) {
    return res.status(403).json({ success: false, error: 'Ruhusa ya admin inahitajika.' });
  }

  const {
    version_name,
    version_code,
    type         = 'minor',   // major | minor | patch
    force_update = false,
    apk_url,
    apk_sha256   = null,
    size_mb      = null,
    changelog    = [],
  } = req.body;

  if (!version_name || !version_code || !apk_url) {
    return res.status(400).json({
      success: false,
      error: 'version_name, version_code, na apk_url zinahitajika.',
    });
  }

  // Thibitisha type
  const validTypes = ['major', 'minor', 'patch'];
  if (!validTypes.includes(type)) {
    return res.status(400).json({
      success: false,
      error: `type lazima iwe moja ya: ${validTypes.join(', ')}.`,
    });
  }

  // major version inapaswa kuwa force update kwa default
  const finalForce = type === 'major' ? true : force_update;

  const result = await supabaseRequest('/app_versions', 'POST', {
    version_name,
    version_code : parseInt(version_code),
    type,
    force_update : finalForce,
    apk_url,
    apk_sha256,
    size_mb      : size_mb ? parseFloat(size_mb) : null,
    changelog    : Array.isArray(changelog) ? changelog : [changelog],
    created_at   : new Date().toISOString(),
  }, true);

  if (!result.success) {
    return res.status(500).json({ success: false, error: 'Imeshindwa kuongeza toleo.' });
  }

  // Futa cache ili app zipate update mpya
  cache.del('latest_version');

  return res.status(201).json({
    success : true,
    message : `Toleo ${version_name} limeongezwa. ${finalForce ? '⚠️ Force update imewashwa.' : ''}`,
    version : result.data?.[0] || null,
  });
});

// ════════════════════════════════════════════════════════════════
//  PATCH /api/update/admin/:id — (admin) hariri toleo
// ════════════════════════════════════════════════════════════════
router.patch('/admin/:id', authMiddleware, async (req, res) => {
  if (!isAdmin(req)) {
    return res.status(403).json({ success: false, error: 'Ruhusa ya admin inahitajika.' });
  }

  const { id } = req.params;
  const allowed = ['force_update', 'apk_url', 'apk_sha256', 'size_mb', 'changelog', 'type'];
  const updates = {};

  for (const key of allowed) {
    if (req.body[key] !== undefined) updates[key] = req.body[key];
  }

  if (!Object.keys(updates).length) {
    return res.status(400).json({ success: false, error: 'Hakuna mabadiliko yaliyotolewa.' });
  }

  const result = await supabaseRequest(
    `/app_versions?id=eq.${id}`,
    'PATCH', updates, true
  );

  if (!result.success) {
    return res.status(500).json({ success: false, error: 'Imeshindwa kusasisha toleo.' });
  }

  cache.del('latest_version');
  return res.json({ success: true, message: 'Toleo limesasishwa.' });
});

// ════════════════════════════════════════════════════════════════
//  DELETE /api/update/admin/:id — (admin) futa toleo
// ════════════════════════════════════════════════════════════════
router.delete('/admin/:id', authMiddleware, async (req, res) => {
  if (!isAdmin(req)) {
    return res.status(403).json({ success: false, error: 'Ruhusa ya admin inahitajika.' });
  }

  const { id } = req.params;

  const result = await supabaseRequest(
    `/app_versions?id=eq.${id}`,
    'DELETE', null, true
  );

  if (!result.success) {
    return res.status(500).json({ success: false, error: 'Imeshindwa kufuta toleo.' });
  }

  cache.del('latest_version');
  return res.json({ success: true, message: 'Toleo limefutwa.' });
});

module.exports = router;
